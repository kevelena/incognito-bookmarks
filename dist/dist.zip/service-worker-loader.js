import './assets/service-worker.ts-DKibNb2e.js';
